﻿namespace P01._Worker_Before
{
    using Contracts;

    public class Human : IWorker
    {
        public void Eat()
        {
            // eat
        }

        public void Sleep()
        {
            // sleep
        }

        public void Work()
        {
            // work
        }
    }
}
